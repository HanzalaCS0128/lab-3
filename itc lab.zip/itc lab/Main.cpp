
#include <iostream>
using namespace std;

int main()
{
    int age, creditHours, feePerCreditHour;

    cout << "Enter your age: ";
    cin >> age;

    cout << "Enter credit hours: ";
    cin >> creditHours;

    cout << "Enter fee per credit hour: ";
    cin >> feePerCreditHour;

    int totalFee = creditHours * feePerCreditHour;
    int discountedFee = totalFee - 2000;

    int birthYear = 2026 - age;
    int yearTurning25 = birthYear + 25;

    cout << "\nTotal fee: Rs " << totalFee << endl;
    cout << "Fee after Rs 2000 discount: Rs "
         << discountedFee << endl;

    cout << "Year of birth: " << birthYear << endl;
    cout << "Year you will turn 25: "
         << yearTurning25 << endl;

    /*
    Experiment 1:
    Values separated by spaces, tabs, or new lines
    are all accepted by cin. The result is the same
    because cin skips whitespace between integer inputs.

    Experiment 2:
    If age is entered as 19.8, age stores 19.
    The decimal part (.8) remains in the input stream.
    The next integer input may fail because it encounters
    the decimal point instead of a valid integer.
    */

    return 0;
}