#include <iostream>
using namespace std;

int main()
{
    int celsius, fahrenheit;

    cout << "Enter temperature in Celsius: ";
    cin >> celsius;

    fahrenheit = celsius * 9 / 5 + 32;

    cout << "Temperature in Fahrenheit: "
         << fahrenheit << endl;

    /*
    Testing:
    Celsius 0 gives Fahrenheit 32.
    Celsius 100 gives Fahrenheit 212.
    Celsius 37 gives Fahrenheit 98.

    A calculator gives 98.6 for 37 Celsius, but
    this program prints 98 because both variables
    are int, so the decimal part is discarded
    during integer division.
    */

    return 0;
}