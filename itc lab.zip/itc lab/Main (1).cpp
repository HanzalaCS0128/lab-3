
#include <iostream>
using namespace std;

int main()
{
    int price, quantity;
    int total, tax, grandTotal;

    cout << "Enter price: ";
    cin >> price;

    cout << "Enter quantity: ";
    cin >> quantity;

    total = price * quantity;
    tax = total * 5 / 100;
    grandTotal = total + tax;

    cout << "Total = " << total << endl;
    cout << "Tax = " << tax << endl;
    cout << "Grand Total = " << grandTotal << endl;

    /*
    Dry run:
    For price = 250 and quantity = 3:
    total = 250 * 3 = 750
    tax = 750 * 5 / 100 = 37
    grandTotal = 750 + 37 = 787

    Experiment:
    For price = 99 and quantity = 7:
    total = 693
    tax = 693 * 5 / 100 = 34
    grandTotal = 693 + 34 = 727

    A calculator gives tax = 34.65, but this program
    prints 34 because all variables are integers.
    Integer division removes the decimal part.
    */

    return 0;
}